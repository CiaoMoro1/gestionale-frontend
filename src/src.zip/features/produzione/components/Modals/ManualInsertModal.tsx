import { useEffect, useRef, useState } from "react";
import type { ProductSuggest, SiteOrdersSummary } from "@/features/produzione";

/* ======================= Tipi extra per evitare any ======================= */
interface ViteImportMetaEnv {
  VITE_API_URL?: string;
}
interface ViteImportMeta {
  readonly env?: ViteImportMetaEnv;
}

/* Tipi per submit */
type SubmitPayload = {
  canale: "Amazon Seller" | "Sito";
  sku: string;
  ean?: string;
  qty: number;
  note?: string;
  plus?: number;
  cavallotti?: boolean;
};

type Props = {
  open: boolean;
  onClose: () => void;
  onSubmit: (p: SubmitPayload) => Promise<void>;
  // Accetta sia array nudo che wrapper { data: [...] } o { items: [...] } ecc.
  onSuggest: (q: string) => Promise<ProductSuggest[] | { data: ProductSuggest[] } | unknown>;
  onFetchSiteSummary: (sku: string) => Promise<SiteOrdersSummary | null>;
};

/* --------------------------- Helpers senza any --------------------------- */
function isRecord(u: unknown): u is Record<string, unknown> {
  return typeof u === "object" && u !== null;
}
function toStringOrNull(v: unknown): string | null {
  if (typeof v === "string") return v;
  if (typeof v === "number") return String(v);
  return null;
}
// --- helper in cima al file (sotto gli altri helper) ---
function withTimeout<T>(p: Promise<T>, ms = 4000): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("timeout")), ms);
    p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
  });
}
async function safeJson(r: Response): Promise<unknown> {
  try { return await r.json(); } catch { return null; }
}
function toNumberOrNull(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? v : null;
}
function normalizeSuggest(u: unknown): ProductSuggest {
  const r = isRecord(u) ? u : {};
  const id =
    toStringOrNull(r["id"]) ??
    toStringOrNull(r["sku"]) ??
    Math.random().toString(36).slice(2);
  return {
    id,
    sku: toStringOrNull(r["sku"]),
    ean: toStringOrNull(r["ean"]),
    variant_title: toStringOrNull(r["variant_title"]),
    product_title: toStringOrNull(r["product_title"]),
    image_url: toStringOrNull(r["image_url"]),
    price: toNumberOrNull(r["price"]),
  };
}
/** Estrae array da forme varie backend */
function unwrapArray(u: unknown): unknown[] {
  if (Array.isArray(u)) return u;
  if (isRecord(u)) {
    const keys = ["data", "results", "items", "rows", "hits", "payload"];
    for (const k of keys) {
      const v = u[k];
      if (Array.isArray(v)) return v as unknown[];
      if (isRecord(v) && Array.isArray(v["items"])) return v["items"] as unknown[];
    }
  }
  return [];
}

/** Base URL robusta per fallback (senza any) */
const API_BASE = ((): string => {
  if (typeof import.meta !== "undefined") {
    const env = (import.meta as unknown as ViteImportMeta).env;
    if (env?.VITE_API_URL) return env.VITE_API_URL;
  }
  return typeof window !== "undefined" ? window.location.origin : "";
})();

/** Limita suggerimenti renderizzati */
const MAX_SUGGEST = 30;

/* ================================ COMPONENTE =============================== */
export default function ManualInsertModal({
  open,
  onClose,
  onSubmit,
  onSuggest,
  onFetchSiteSummary,
}: Props) {
  /* Form */
  const [canale, setCanale] = useState<"" | "Amazon Seller" | "Sito">("");
  const [sku, setSku] = useState("");
  const [ean, setEan] = useState("");
  const [qty, setQty] = useState<number | "">("");
  const [plus, setPlus] = useState<number | "">("");
  const [note, setNote] = useState("");
  const [cavallotti, setCavallotti] = useState(false);

  /* Ricerca */
  const [q, setQ] = useState("");
  const [sug, setSug] = useState<ProductSuggest[]>([]);
  const [loadingSug, setLoadingSug] = useState(false);
  const [errorSug, setErrorSug] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState<number>(-1); // per tastiera

  /* Site summary */
  const [siteInfo, setSiteInfo] = useState<SiteOrdersSummary | null>(null);
  const [loadingSite, setLoadingSite] = useState(false);

  /* Errori submit */
  const [submitError, setSubmitError] = useState<string | null>(null);

  /* Guard race */
  const reqIdRef = useRef(0);

  const inputRef = useRef<HTMLInputElement | null>(null);
  const listboxId = "manual-insert-suggest-listbox";

  /* Focus e reset all’apertura/chiusura */
  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 0);
    } else {
      // reset quando si chiude
      setQ("");
      setSug([]);
      setActiveIndex(-1);
      setErrorSug(null);
      setSubmitError(null);
      setCanale("");
      setSku("");
      setEan("");
      setQty("");
      setPlus("");
      setNote("");
      setCavallotti(false);
      setSiteInfo(null);
    }
  }, [open]);

  /* Ricerca: debounce + unwrap + normalize + fallback + abort */
  useEffect(() => {
    if (!open) return;

    const query = q.trim();
    if (query.length < 2) {
      setSug([]);
      setLoadingSug(false);
      setErrorSug(null);
      setActiveIndex(-1);
      return;
    }

    const myReqId = ++reqIdRef.current;
    let cancelled = false;
    const ctrl = new AbortController();

    setLoadingSug(true);
    setErrorSug(null);

    const t = setTimeout(async () => {
      try {
        // 1) kickoff suggest del genitore con timeout
        const primary = withTimeout(Promise.resolve(onSuggest(query)), 4000)
          .then(unwrapArray)
          .then(arr => arr.map(normalizeSuggest))
          .catch(() => [] as ProductSuggest[]);

        // 2) fallback in parallelo con timeout (solo se API_BASE presente)
        const fallback = (API_BASE
          ? withTimeout(
              fetch(new URL(`/api/products/search?q=${encodeURIComponent(query)}`, API_BASE).toString(), { signal: ctrl.signal })
                .then(r => r.ok ? safeJson(r) : Promise.reject(new Error(String(r.status))))
                .then(unwrapArray)
                .then(arr => arr.map(normalizeSuggest)),
              4000
            ).catch(() => [] as ProductSuggest[])
          : Promise.resolve([] as ProductSuggest[])
        );

        // 3) prendi il primo NON VUOTO, altrimenti prendi quello che arriva prima
        const [a, b] = await Promise.allSettled([primary, fallback]);
        const A = a.status === "fulfilled" ? a.value as ProductSuggest[] : [];
        const B = b.status === "fulfilled" ? b.value as ProductSuggest[] : [];
        const merged = (A.length ? A : (B.length ? B : (A.length >= B.length ? A : B))).slice(0, MAX_SUGGEST);

        if (cancelled || myReqId !== reqIdRef.current) return;
        setSug(merged);
        setActiveIndex(merged.length ? 0 : -1);
        if (!merged.length) setErrorSug("Nessun risultato o errore di ricerca.");
      } catch {
        if (cancelled || myReqId !== reqIdRef.current) return;
        setSug([]);
        setActiveIndex(-1);
        setErrorSug("Errore durante la ricerca.");
      } finally {
        // spegni SEMPRE lo spinner per questa run
        if (!cancelled) setLoadingSug(false);
      }
    }, 260);

    return () => {
      cancelled = true;
      ctrl.abort();
      clearTimeout(t);
      // spegni spinner della richiesta abortita (evita restare bloccato)
      setLoadingSug(false);
    };
  }, [q, onSuggest, open]);

  /* Riepilogo ordini Sito */
  useEffect(() => {
    if (!open) return;
    const s = sku.trim();
    if (canale !== "Sito" || !s) {
      setSiteInfo(null);
      return;
    }
    let cancelled = false;
    setLoadingSite(true);
    onFetchSiteSummary(s)
      .then((d) => {
        if (!cancelled) setSiteInfo(d);
      })
      .catch(() => {
        if (!cancelled) setSiteInfo(null);
      })
      .finally(() => {
        if (!cancelled) setLoadingSite(false);
      });
    return () => {
      cancelled = true;
    };
  }, [canale, sku, onFetchSiteSummary, open]);

  if (!open) return null;

  function acceptSuggestion(s: ProductSuggest) {
    setSku(s.sku || "");
    setEan(s.ean || "");
    setQ(s.sku || s.ean || "");
    setSug([]);
    setActiveIndex(-1);
  }

  async function handleSubmit() {
    setSubmitError(null);
    try {
      if (!canale || !sku || !qty) {
        setSubmitError("Compila i campi obbligatori (Canale, SKU, Qty).");
        return;
      }
      await onSubmit({
        canale,
        sku: sku.trim(),
        ean: ean.trim() || undefined,
        qty: Number(qty),
        note: note.trim() || undefined,
        plus: plus === "" ? undefined : Number(plus),
        cavallotti,
      });
      onClose();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Errore durante l'inserimento.";
      setSubmitError(msg);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div
        className="bg-white rounded-2xl p-6 shadow-2xl border w-full max-w-md relative"
        role="dialog"
        aria-modal
        aria-labelledby="manual-insert-title"
      >
        <button
          className="absolute top-2 right-3 text-2xl text-neutral-400 hover:text-black"
          onClick={onClose}
          type="button"
          aria-label="Chiudi"
        >
          ×
        </button>

        <div id="manual-insert-title" className="font-bold text-lg mb-4 text-blue-900">
          Inserimento manuale in produzione
        </div>

        <div className="grid gap-3">
          {/* Canale */}
          <div>
            <label className="block text-xs font-semibold mb-1">Canale *</label>
            <select
              className="w-full border rounded-xl px-3 py-2"
              value={canale}
              onChange={(e) => setCanale(e.target.value as "Amazon Seller" | "Sito" | "")}
            >
              <option value="">Seleziona…</option>
              <option value="Amazon Seller">Amazon Seller</option>
              <option value="Sito">Sito</option>
            </select>
          </div>

          {/* Ricerca prodotti */}
          <div>
            <label className="block text-xs font-semibold mb-1">
              Cerca prodotto (SKU/EAN)
            </label>
            <input
              ref={inputRef}
              className="w-full border rounded-xl px-3 py-2"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setErrorSug(null);
              }}
              onKeyDown={(e) => {
                if (!sug.length) return;
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setActiveIndex((i) => (i + 1) % sug.length);
                } else if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setActiveIndex((i) => (i - 1 + sug.length) % sug.length);
                } else if (e.key === "Enter") {
                  if (activeIndex >= 0 && activeIndex < sug.length) {
                    e.preventDefault();
                    acceptSuggestion(sug[activeIndex]);
                  }
                } else if (e.key === "Escape") {
                  setSug([]);
                  setActiveIndex(-1);
                }
              }}
              placeholder='Es. "2p;" per token finale, "805...;" per EAN'
              aria-autocomplete="list"
              aria-controls={sug.length ? listboxId : undefined}
              aria-expanded={!!sug.length}
              role="combobox"
            />
            {/* Feedback stato */}
            {loadingSug && <div className="text-xs text-gray-500 mt-1">Caricamento…</div>}
            {!loadingSug && errorSug && (
              <div className="text-xs text-red-600 mt-1">{errorSug}</div>
            )}
            {!loadingSug && !errorSug && q.trim().length >= 2 && (
              <div className="text-[11px] text-slate-500 mt-1">
                Trovati: <b>{sug.length}</b>
              </div>
            )}
            {!loadingSug && !errorSug && q.trim().length >= 2 && sug.length === 0 && (
              <div className="text-xs text-gray-500 mt-1">Nessun risultato</div>
            )}

            {/* Tendina suggerimenti */}
            {sug.length > 0 && (
              <div
                id={listboxId}
                role="listbox"
                className="mt-1 border rounded-xl bg-white shadow max-h-56 overflow-y-auto z-[9999] relative"
              >
                {sug.map((s, i) => {
                  const active = i === activeIndex;
                  return (
                    <div
                      key={`${s.id}-${i}`}
                      role="option"
                      aria-selected={active}
                      className={[
                        "px-3 py-2 cursor-pointer flex items-center gap-3",
                        active ? "bg-cyan-50" : "hover:bg-cyan-50",
                      ].join(" ")}
                      onMouseEnter={() => setActiveIndex(i)}
                      onMouseDown={(ev) => ev.preventDefault()} // evita blur input
                      onClick={() => acceptSuggestion(s)}
                    >
                      {s.image_url ? (
                        <img
                          src={s.image_url}
                          className="w-8 h-8 rounded object-cover"
                          alt=""
                        />
                      ) : (
                        <div className="w-8 h-8 rounded bg-gray-100" />
                      )}
                      <div className="flex-1">
                        <div className="font-mono font-bold">
                          {s.sku || "—"}
                        </div>
                        <div className="text-xs text-gray-600">
                          {s.ean ? `EAN: ${s.ean} • ` : ""}
                          {s.product_title || s.variant_title || ""}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* SKU/EAN */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1">SKU *</label>
              <input
                className="w-full border rounded-xl px-3 py-2"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">EAN</label>
              <input
                className="w-full border rounded-xl px-3 py-2"
                value={ean}
                onChange={(e) => setEan(e.target.value)}
              />
            </div>
          </div>

          {/* Qty/Plus */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1">Qty *</label>
              <input
                type="number"
                min={1}
                className="w-full border rounded-xl px-3 py-2"
                value={qty}
                onChange={(e) =>
                  setQty(e.target.value === "" ? "" : Number(e.target.value))
                }
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">Plus</label>
              <input
                type="number"
                min={0}
                className="w-full border rounded-xl px-3 py-2"
                value={plus}
                onChange={(e) =>
                  setPlus(e.target.value === "" ? "" : Number(e.target.value))
                }
              />
            </div>
          </div>

          {/* Riepilogo Sito */}
          {canale === "Sito" && sku.trim() && (
            <div className="rounded-xl border px-3 py-2 bg-green-50 text-green-900 text-sm">
              {loadingSite ? (
                "Verifica ordini Sito in corso…"
              ) : siteInfo ? (
                <>
                  Ordini Sito per <b>{sku}</b>: <b>{siteInfo.orders_count}</b> ordini – totale{" "}
                  <b>{siteInfo.total_qty}</b> pezzi
                </>
              ) : (
                "Nessun ordine Sito aperto per questo SKU."
              )}
            </div>
          )}

          {/* Nota + cavallotti */}
          <div>
            <label className="block text-xs font-semibold mb-1">Nota</label>
            <input
              className="w-full border rounded-xl px-3 py-2"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
          <label className="inline-flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={cavallotti}
              onChange={(e) => setCavallotti(e.target.checked)}
            />
            Cavallotti
          </label>

          {submitError && (
            <div className="text-sm text-red-600">{submitError}</div>
          )}
        </div>

        {/* Footer */}
        <div className="flex gap-2 mt-5 justify-between">
          <button
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-300"
            onClick={onClose}
            type="button"
          >
            Annulla
          </button>
          <button
            className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 shadow"
            onClick={handleSubmit}
            disabled={!canale || !sku || !qty || Number(qty) < 1}
            type="button"
          >
            Inserisci
          </button>
        </div>
      </div>
    </div>
  );
}
