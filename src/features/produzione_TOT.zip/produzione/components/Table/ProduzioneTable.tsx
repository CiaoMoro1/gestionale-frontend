import type { ProduzioneRow } from "@/features/produzione";
import { TITOLO_DA_PRODURRE } from "@/features/produzione";
import { ProduzioneRowView } from "./ProduzioneRowView";

type Props = {
  rows: ProduzioneRow[];
  allRows: ProduzioneRow[];
  sameSku: (a?: string, b?: string) => boolean;

  selectedIds: number[];
  selectAllChecked: boolean;
  onToggleSelect: (id: number, on: boolean) => void;
  onToggleSelectAll: (on: boolean) => void;

  onInlineChangeDaStampare: (id: number, value: number) => Promise<void>;
  onOpenLogs: (rowId: number) => Promise<void>;
  onToggleCavallotti: (row: ProduzioneRow) => Promise<void>;
  onOpenCavallottoPdf: (sku: string, formato: string) => void;

  onOpenNota?: (row: ProduzioneRow) => void;
  onOpenDaProdurre?: (row: ProduzioneRow) => void;
  onOpenChangeState?: (row: ProduzioneRow) => void;

  statoLabel?: string;
};

export function ProduzioneTable(props: Props) {
  const {
    rows, allRows, sameSku,
    selectedIds, selectAllChecked,
    onToggleSelect, onToggleSelectAll,
    onInlineChangeDaStampare, onOpenLogs,
    onToggleCavallotti, onOpenCavallottoPdf,
    onOpenNota, onOpenDaProdurre, onOpenChangeState,
    statoLabel,
  } = props;

  const defaultLabel = TITOLO_DA_PRODURRE[""] || "Inseriti";
  const headLabel = statoLabel ?? defaultLabel;

  return (
    <div className="rounded-2xl w-full shadow-xl border bg-white px-2 sm:px-4 py-2 mb-10 overflow-x-auto">
      {/* layout fluido: font responsive, larghezze guidate dai th */}
      <table className="w-full table-auto text-sm md:text-base lg:text-[17px]">
        {/* header sticky; z-20 < z dei dropdown (z-[1000]) */}
        <thead className="bg-white sticky top-0 z-20">
          <tr className="border-b border-gray-200 text-slate-700 whitespace-nowrap">
            {/* Seleziona tutto */}
            <th className="w-[44px] px-2 py-2 text-center">
              <input
                type="checkbox"
                checked={selectAllChecked}
                onChange={(e) => onToggleSelectAll(e.target.checked)}
              />
            </th>

            {/* SKU largo e non comprimibile */}
            <th className="px-2 py-2 text-left w-52 md:w-64 lg:w-[14rem]">SKU</th>

            {/* Canale compatto */}
            <th className="px-1 py-2 text-center w-24 md:w-28">Canale</th>

            {/* Qty stretta */}
            <th className="px-2 py-2 text-center w-14 md:w-20">Qty</th>

            {/* Inseriti elastica */}
            <th className="px-2 py-2 text-center">{headLabel}</th>

            {/* Stato: larghezza minima per badge */}
            <th className="px-3 py-2 text-center min-w-[160px]">Stato</th>

            {/* Nota / Cavallotti / EAN / Azioni */}
            <th className="px-3 py-2 text-center w-[110px]">Nota</th>
            <th className="px-3 py-2 text-center w-[120px]">Cavallotti</th>
            <th className="px-3 py-2 text-left w-[18ch] md:w-[22ch]">EAN</th>
            <th className="px-3 py-2 text-center w-[100px]">Azioni</th>
          </tr>
        </thead>

        <tbody>
          {rows.map((r, idx) => (
            <ProduzioneRowView
              key={r.id}
              row={r}
              prevRow={idx > 0 ? rows[idx - 1] : undefined}
              nextRow={idx < rows.length - 1 ? rows[idx + 1] : undefined}
              allRows={allRows}
              sameSku={sameSku}
              selected={selectedIds.includes(r.id)}
              onSelect={(on) => onToggleSelect(r.id, on)}
              onInlineChangeDaStampare={onInlineChangeDaStampare}
              onOpenLogs={onOpenLogs}
              onToggleCavallotti={onToggleCavallotti}
              onOpenCavallottoPdf={onOpenCavallottoPdf}
              onOpenNota={onOpenNota}
              onOpenDaProdurre={onOpenDaProdurre}
              onOpenChangeState={onOpenChangeState}
            />
          ))}

          {rows.length === 0 && (
            <tr>
              {/* 10 colonne totali */}
              <td colSpan={10} className="text-center text-gray-400 py-6 text-lg">
                Nessun articolo in produzione trovato.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
