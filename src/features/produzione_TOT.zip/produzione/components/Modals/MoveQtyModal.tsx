import type { ProduzioneRow, StatoProduzione } from "@/features/produzione";
import { badgeCanale } from "@/features/produzione";

type Props = {
  open: boolean;
  row: ProduzioneRow | null;
  toState: StatoProduzione;
  setToState: (s: StatoProduzione) => void;
  qty: number;
  setQty: (n: number) => void;
  onClose: () => void;
  onMove: (row: ProduzioneRow, to: StatoProduzione, qty: number) => Promise<void>;
  statiDisponibili: StatoProduzione[];
};

export default function MoveQtyModal({
  open, row, toState, setToState, qty, setQty, onClose, onMove, statiDisponibili
}: Props) {
  if (!open || !row) return null;

  const maxQty = row.da_produrre;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white rounded-2xl p-6 shadow-2xl border w-full max-w-sm relative" role="dialog" aria-modal>
        <button
          className="absolute top-2 right-3 text-neutral-400 hover:text-black text-2xl"
          onClick={onClose}
          aria-label="Chiudi"
        >
          ×
        </button>
        <div className="font-bold text-lg mb-2 text-blue-900">Sposta quantità</div>
        <div className="text-xs text-gray-500 mb-3">
          {row.sku} • {badgeCanale(row.canale)} • {row.start_delivery ?? "—"}
        </div>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <label className="block text-xs font-semibold mb-1">Da</label>
            <div className="font-bold">{row.stato_produzione}</div>
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1">A</label>
            <select
              className="w-full border rounded-xl px-3 py-2 font-bold"
              value={toState}
              onChange={(e) => setToState(e.target.value as StatoProduzione)}
            >
              {statiDisponibili.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="mb-2">
          <label className="block text-xs font-semibold mb-1">Pezzi da spostare (max {maxQty})</label>
          <input
            type="number"
            min={1}
            max={maxQty}
            value={qty}
            onChange={(e) => {
              const v = Number.parseInt(e.target.value, 10);
              setQty(Number.isFinite(v) ? Math.max(1, Math.min(v, maxQty)) : 1);
            }}
            className="w-full border rounded-xl px-3 py-2 font-bold text-blue-800"
          />
        </div>
        <div className="flex justify-between mt-4">
          <button className="px-4 py-2 bg-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-300" onClick={onClose}>
            Annulla
          </button>
          <button
            className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700"
            onClick={() => onMove(row, toState, qty)}
          >
            Sposta
          </button>
        </div>
      </div>
    </div>
  );
}
