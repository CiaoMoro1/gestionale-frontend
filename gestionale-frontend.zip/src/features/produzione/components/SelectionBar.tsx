/* src/features/produzione/components/SelectionBar.tsx */
import type { StatoProduzione } from "@/features/produzione";

type Props = {
  count: number;
  states: StatoProduzione[];
  stateLabels: Record<string, string>;
  onClear: () => void;
  onBulkSetState: (stato: StatoProduzione) => void;
  onBulkDelete: () => void;
  onExportPdf: (orderBy: "az" | "misura") => void;
};

export function SelectionBar({
  count,
  states,
  stateLabels,
  onClear,
  onBulkSetState,
  onBulkDelete,
  onExportPdf,
}: Props) {
  return (
    <div className="sticky top-2 z-40 flex flex-wrap items-center gap-3 bg-white/90 backdrop-blur-md rounded-2xl shadow-xl px-6 py-3 mb-4 border">
      <span className="text-lg font-bold text-cyan-800">
        {count} selezionat{count === 1 ? "o" : "i"}
      </span>

      <div className="flex gap-2 flex-wrap">
        {states.map((st) => (
          <button
            key={st}
            className="px-3 py-2 rounded-xl font-bold text-sm bg-gradient-to-tr from-blue-300 to-cyan-400 border border-blue-400 text-blue-900 hover:from-blue-400 hover:to-cyan-500 transition"
            onClick={() => onBulkSetState(st)}
          >
            Segna come {stateLabels[st]}
          </button>
        ))}

        <button
          className="px-3 py-2 rounded-xl font-bold bg-gray-200 text-gray-700 hover:bg-gray-300 text-sm"
          onClick={onClear}
        >
          Deseleziona tutto
        </button>

        <button
          className="px-3 py-2 rounded-xl font-bold bg-orange-100 text-orange-800 hover:bg-orange-200 text-sm"
          onClick={() => onExportPdf("az")}
        >
          📄 Export PDF (A-Z)
        </button>
        <button
          className="px-3 py-2 rounded-xl font-bold bg-orange-100 text-orange-800 hover:bg-orange-200 text-sm"
          onClick={() => onExportPdf("misura")}
        >
          📄 Export PDF (Misura)
        </button>
      </div>

      <div className="ml-auto flex gap-2">
        <button
          className="px-3 py-2 rounded-xl font-bold bg-red-100 text-red-700 hover:bg-red-200 text-sm"
          onClick={onBulkDelete}
        >
          Rimuovi da produzione
        </button>
      </div>
    </div>
  );
}
