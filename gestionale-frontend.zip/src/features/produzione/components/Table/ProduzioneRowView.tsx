import React, { memo, type ReactNode } from "react";
import type { ProduzioneRow, StatoProduzione } from "@/features/produzione";
import { badgeCanale, badgeStato, rowBgByCanale } from "@/features/produzione";
import { Edit, Info } from "lucide-react";

/** Colore pastello deterministico per SKU (banda) */
function colorForSku(sku: string): string {
  let h = 4450;
  for (let i = 0; i < sku.length; i++) h = ((h << 5) + h) + sku.charCodeAt(i);
  const hue = Math.abs(h) % 360;
  return `hsl(${hue}deg 70% 65%)`;
}

type Props = {
  row: ProduzioneRow;
  prevRow?: ProduzioneRow;
  nextRow?: ProduzioneRow;
  /** Tutte le righe (solo per fallback calcoli se non viene passata flowTotalsMap) */
  allRows: ProduzioneRow[];
  /** Confronto SKU case-insensitive/trim */
  sameSku: (a?: string, b?: string) => boolean;

  /** Mappa precomputata dei totali per (sku,canale): consigliata per performance */
  flowTotalsMap?: Map<string, Record<StatoProduzione, number>>;

  /** Selezione riga */
  selected: boolean;
  onSelect: (on: boolean) => void;

  /** Azioni riga */
  onInlineChangeDaStampare: (id: number, value: number) => Promise<void>;
  onOpenLogs: (rowId: number) => Promise<void>;
  onToggleCavallotti: (row: ProduzioneRow) => Promise<void>;
  onOpenCavallottoPdf: (sku: string, formato: string) => void;

  onOpenNota?: (row: ProduzioneRow) => void;
  onOpenDaProdurre?: (row: ProduzioneRow) => void;
  onOpenChangeState?: (row: ProduzioneRow) => void;
};

const ORDER_STATES: StatoProduzione[] = [
  "Da Stampare",
  "Stampato",
  "Calandrato",
  "Cucito",
  "Confezionato",
  "Trasferito",
  "Deposito",
];

const STATE_LABEL: Record<StatoProduzione, string> = {
  "Da Stampare": "Da Stampare",
  "Stampato": "Stampati",
  "Calandrato": "Calandrati",
  "Cucito": "Cuciti",
  "Confezionato": "Confezionati",
  "Trasferito": "Trasferiti",
  "Deposito": "In Deposito",
  "Rimossi": "Rimossi",
};

function RowViewBase({
  row, prevRow, nextRow, allRows, sameSku, flowTotalsMap,
  selected, onSelect,
  onInlineChangeDaStampare, onOpenLogs, onToggleCavallotti, onOpenCavallottoPdf,
  onOpenNota, onOpenDaProdurre, onOpenChangeState,
}: Props) {
  const isGroupStart = !prevRow || !sameSku(prevRow?.sku, row.sku);
  const isGroupEnd   = !nextRow || !sameSku(nextRow?.sku, row.sku);
  const rowBg = rowBgByCanale(row.canale);

  // ---- Banda visiva per lo SKU (tutti i canali/stati)
  const visualGroupCount = allRows.reduce((acc, r) => acc + (r.sku === row.sku ? 1 : 0), 0);
  const groupHasMultiple = visualGroupCount > 1;

  const shadows: string[] = [];
  if (groupHasMultiple) shadows.push(`inset 6px 0 0 0 ${colorForSku(row.sku)}`); // banda SKU
  if (prevRow && sameSku(prevRow.sku, row.sku)) shadows.push("inset 0 1px 0 0 rgba(15,23,42,0.12)"); // separatore gruppi

  // ---- Totali flusso per CANALE: usa la mappa O(1) se c’è; altrimenti fallback al calcolo locale
  const totalsKey = `${row.sku}__${row.canale ?? ""}`;
  let flowTotals: Record<StatoProduzione, number> | undefined = flowTotalsMap?.get(totalsKey);
  if (!flowTotals) {
    const init: Record<StatoProduzione, number> = {
      "Da Stampare": 0, "Stampato": 0, "Calandrato": 0, "Cucito": 0,
      "Confezionato": 0, "Trasferito": 0, "Deposito": 0, "Rimossi": 0,
    };
    for (const g of allRows) {
      if (g.sku === row.sku && g.canale === row.canale) {
        init[g.stato_produzione] += g.da_produrre || 0;
      }
    }
    flowTotals = init;
  }

  const initialTotal = ORDER_STATES.reduce((acc, st) => acc + (flowTotals![st] || 0), 0);

  // Riepilogo sopra “Inseriti”
  const summaryParts: ReactNode[] = [];
  for (const st of ORDER_STATES) {
    const q = flowTotals![st] || 0;
    if (q > 0) {
      if (summaryParts.length > 0) summaryParts.push(" + ");
      summaryParts.push(
        <span key={`sum-${st}`} className={st === "Da Stampare" ? "text-blue-900 font-bold" : ""}>
          {q} {STATE_LABEL[st]}
        </span>
      );
    }
  }

  function qtyColValue(): number {
    return row.stato_produzione === "Da Stampare" ? initialTotal : row.da_produrre;
  }

  return (
    <tr
      className={`${rowBg} ${isGroupStart ? "border-t-2 border-slate-200" : ""} transition-colors duration-150 hover:brightness-95`}
      style={{
        boxShadow: shadows.join(", "),
        borderTopLeftRadius:    groupHasMultiple && isGroupStart ? 12 : 0,
        borderBottomLeftRadius: groupHasMultiple && isGroupEnd   ? 12 : 0,
      }}
    >
      {/* Selezione */}
      <td className="w-[44px] px-2 py-2 text-center align-middle">
        <input
          type="checkbox"
          checked={selected}
          onChange={(e) => onSelect(e.target.checked)}
          aria-label={selected ? "Deseleziona riga" : "Seleziona riga"}
        />
      </td>

      {/* SKU */}
      <td className="px-2 py-2 font-mono font-bold w-52 md:w-64 lg:w-[14rem] min-w-52 md:min-w-64 lg:min-w-[14rem] break-words">
        {row.sku}
      </td>

      {/* Canale */}
      <td className="px-1 py-2 w-24 md:w-28 text-center align-middle">
        {badgeCanale(row.canale)}
      </td>

      {/* Qty grande */}
      <td className="px-2 py-2 text-center font-bold text-base text-blue-800 w-14 md:w-20 align-middle">
        <span style={{ fontSize: "clamp(1.1rem, 1.1vw + 0.6rem, 1.6rem)", lineHeight: 1 }}>
          {qtyColValue()}
        </span>
        {row.modificata_manualmente && (
          <span
            className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-full border bg-yellow-50 border-yellow-300 text-yellow-800 text-[11px] font-semibold whitespace-nowrap"
            title="Questa quantità è stata modificata manualmente"
          >
            <Edit className="w-3 h-3" />
            Mod. Manuale
          </span>
        )}
      </td>

      {/* Inseriti + edit DS */}
      <td className="px-2 py-2 text-center font-bold text-base text-blue-800 align-middle">
        <div className="text-xs text-gray-600 font-medium italic mb-1 leading-4">
          {summaryParts.length > 0 ? summaryParts : <span>0</span>}
        </div>

        {row.stato_produzione === "Da Stampare" ? (
          <input
            type="number"
            min={0}
            defaultValue={row.da_produrre}
            className="input input-bordered px-2 py-1 rounded-xl text-blue-800 font-bold w-20 text-center"
            aria-label="Modifica da produrre"
            onBlur={async (e) => {
              const vParsed = parseInt(e.target.value, 10);
              const v = Number.isFinite(vParsed) ? vParsed : 0;
              if (v !== row.da_produrre) await onInlineChangeDaStampare(row.id, v);
            }}
            onKeyDown={(e) => { if (e.key === "Enter") (e.currentTarget as HTMLInputElement).blur(); }}
          />
        ) : (
          <div className="inline-flex items-center gap-2">
            <span>{row.da_produrre}</span>
            <button
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border text-xs bg-gray-100 hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-cyan-300"
              title="Modifica quantità"
              aria-label="Modifica quantità"
              onClick={() => onOpenDaProdurre?.(row)}
            >
              <Edit className="w-4 h-4 text-cyan-700" />
              Modifica
            </button>
          </div>
        )}
      </td>

      {/* Stato */}
      <td className="px-3 py-2 text-center min-w-[160px]">
        <button
          type="button"
          className="inline-block rounded-full focus:outline-none focus:ring-2 focus:ring-cyan-300"
          onClick={() => onOpenChangeState?.(row)}
          title="Cambia stato / Sposta quantità"
          aria-label="Cambia stato o sposta quantità"
        >
          {badgeStato(row.stato_produzione)}
        </button>
      </td>

      {/* Nota */}
      <td className="px-3 py-2 text-center">
        {(() => {
          const hasNote = Boolean(row.note && row.note.trim());
          return (
            <button
              className={`px-2 py-1 rounded-xl border text-xs transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-300 ${
                hasNote
                  ? "bg-red-100 hover:bg-red-200 border-red-300 text-red-700"
                  : "bg-gray-100 hover:bg-gray-200 border-gray-300 text-gray-700"
              }`}
              onClick={() => onOpenNota?.(row)}
              title={hasNote ? "Nota presente" : "Aggiungi nota"}
              aria-label={hasNote ? "Nota presente" : "Aggiungi nota"}
            >
              Nota
            </button>
          );
        })()}
      </td>

      {/* Cavallotti */}
      <td className="px-3 py-2 text-center">
        <button
          className={`inline-flex items-center rounded-xl px-2 py-1 border text-xs focus:outline-none focus:ring-2 focus:ring-cyan-300 ${
            row.cavallotti ? "bg-green-200 text-green-700 border-green-300" : "bg-gray-200 text-gray-600 border-gray-300"
          }`}
          onClick={() => onToggleCavallotti(row)}
          title="Toggle cavallotti"
          aria-label={row.cavallotti ? "Disattiva cavallotti" : "Attiva cavallotti"}
        >
          {row.cavallotti ? "Cavallotti" : "No"}
        </button>
        {row.cavallotti && (
          <button
            className="ml-2 px-2 py-1 bg-cyan-100 border border-cyan-300 rounded-xl text-cyan-800 text-xs font-semibold hover:bg-cyan-200 focus:outline-none focus:ring-2 focus:ring-cyan-300"
            onClick={() => onOpenCavallottoPdf(row.sku, "A5")}
            title="Stampa Cavallotto"
            aria-label="Stampa cavallotto in PDF"
          >
            🏷️ PDF
          </button>
        )}
      </td>

      {/* EAN */}
      <td className="px-3 py-2 font-mono truncate max-w-[16ch] md:max-w-[20ch]">{row.ean}</td>

      {/* Azioni: Log */}
      <td className="px-3 py-2 text-center">
        <button
          className="rounded-full p-2 bg-gray-100 hover:bg-blue-100 transition focus:outline-none focus:ring-2 focus:ring-cyan-300"
          title="Storico movimenti"
          aria-label="Apri storico movimenti"
          onClick={() => onOpenLogs(row.id)}
        >
          <Info size={18} className="text-blue-700" />
        </button>
      </td>
    </tr>
  );
}

/** memo per evitare re-render inutili delle righe */
export const ProduzioneRowView = memo(RowViewBase, (prev, next) => {
  // Re-render solo quando cambia qualcosa di rilevante
  const a = prev.row, b = next.row;
  return (
    prev.selected === next.selected &&
    prev.sameSku(prev.prevRow?.sku, a.sku) === next.sameSku(next.prevRow?.sku, b.sku) &&
    prev.sameSku(prev.nextRow?.sku, a.sku) === next.sameSku(next.nextRow?.sku, b.sku) &&
    a.id === b.id &&
    a.da_produrre === b.da_produrre &&
    a.stato_produzione === b.stato_produzione &&
    a.note === b.note &&
    a.cavallotti === b.cavallotti
  );
});

export default ProduzioneRowView;
