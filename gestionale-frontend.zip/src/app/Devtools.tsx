/* src/app/Devtools.tsx */

export default function Devtools(){ return null; } // placeholder (add React Query devtools if desired)
