declare module "quagga";
