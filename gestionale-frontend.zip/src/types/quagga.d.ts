declare module "quagga";
