export interface AuditDetails {
  number?: string;
  sku?: string;
  from?: string;
  to?: string;
  [key: string]: unknown;
}