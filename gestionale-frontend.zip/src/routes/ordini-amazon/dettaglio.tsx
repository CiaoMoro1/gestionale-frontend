import { useState } from "react";
import { Package, Plus } from "lucide-react";

type Articolo = {
  sku: string;
  nome: string;
  quantita_ordinata: number;
  quantita_confermata: number;
  // puoi aggiungere altri campi se vuoi!
};

const ARTICOLI_MOCK: Articolo[] = [
  { sku: "TOVCD-MZ", nome: "Tovaglia Mazzo", quantita_ordinata: 10, quantita_confermata: 0 },
  { sku: "FOD-PLT", nome: "Fodera Pillow", quantita_ordinata: 5, quantita_confermata: 0 },
];

export default function DettaglioOrdine() {
  // Colli gestiti come array dinamico
  const [colli, setColli] = useState([1]);
  // Stato per le quantità parziali: { [sku]: { [collo]: qty } }
  const [parziali, setParziali] = useState<{ [sku: string]: { [collo: number]: number } }>({});

  // Handler per cambiare quantità
  function handleChange(sku: string, collo: number, value: number) {
    setParziali(prev => ({
      ...prev,
      [sku]: {
        ...prev[sku],
        [collo]: Math.max(0, value),
      }
    }));
  }

  // Somma le quantità per confermata
  function totaleParziale(sku: string) {
    return colli.reduce((tot, c) => tot + (parziali[sku]?.[c] || 0), 0);
  }

  // Aggiungi un nuovo collo (max 10 per demo)
  function aggiungiCollo() {
    if (colli.length < 10) setColli(prev => [...prev, prev.length + 1]);
  }

  return (
    <div className="max-w-3xl mx-auto my-6 px-2">
      {/* Header */}
      <div className="flex flex-col gap-2 mb-4 px-2">
        <div className="flex items-center gap-3">
          <Package className="text-blue-600" size={32} />
          <div>
            <div className="font-bold text-xl uppercase">PO: 5UVX1XLY</div>
            <div className="text-neutral-600 text-sm">Destinazione: <b>BGY1</b> &bull; Data: <b>2025-06-25</b> &bull; Stato: <span className="text-blue-700 font-bold">NUOVO</span></div>
          </div>
        </div>
      </div>
      {/* Tabella articoli */}
      <div className="rounded-2xl shadow bg-white/80 backdrop-blur px-2 overflow-x-auto">
        <table className="w-full min-w-[500px] text-base">
          <thead>
            <tr>
              <th className="text-left px-2 py-3">SKU</th>
              <th className="text-left px-2">Q. Ordinata</th>
              {colli.map(c => (
                <th key={c} className="text-center px-2">{c}° Collo</th>
              ))}
              <th className="text-left px-2">Confermata</th>
            </tr>
          </thead>
          <tbody>
            {ARTICOLI_MOCK.map((art) => (
              <tr key={art.sku} className="border-t">
                <td className="font-mono px-2 py-2">
                  <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-900 px-2 py-1 rounded-full cursor-pointer font-semibold">{art.sku}</span>
                </td>
                <td className="px-2 py-2 text-center">{art.quantita_ordinata}</td>
                {colli.map(c => (
                  <td key={c} className="px-2 py-2">
                    <input
                      type="number"
                      min={0}
                      max={art.quantita_ordinata}
                      value={parziali[art.sku]?.[c] || ""}
                      onChange={e => handleChange(art.sku, c, Number(e.target.value))}
                      className="w-16 text-center bg-white border rounded-lg px-2 py-1 outline-blue-400"
                    />
                  </td>
                ))}
                <td className="px-2 py-2 text-blue-800 font-bold text-center">
                  {totaleParziale(art.sku)}
                </td>
              </tr>
            ))}
            {/* Riga per aggiungere collo */}
            <tr>
              <td colSpan={2 + colli.length + 1} className="pt-4 text-center">
                <button
                  onClick={aggiungiCollo}
                  className="inline-flex items-center gap-1 px-3 py-2 bg-blue-50 border border-blue-200 rounded-xl shadow-sm text-blue-700 font-semibold hover:bg-blue-100"
                >
                  <Plus size={18} /> Aggiungi Collo
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      {/* Bottone conferma */}
      <div className="mt-6 flex flex-col sm:flex-row gap-4 justify-end">
        <button className="w-full sm:w-auto bg-blue-600 text-white font-bold rounded-xl px-6 py-3 shadow hover:bg-blue-700 transition">
          Conferma e Salva
        </button>
        <button className="w-full sm:w-auto bg-green-500 text-white font-bold rounded-xl px-6 py-3 shadow hover:bg-green-600 transition">
          Conferma Spedizione
        </button>
      </div>
    </div>
  );
}
